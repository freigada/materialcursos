# GetYourLoanApp

![enter image description here](https://www.pluralsight.com/content/dam/pluralsight/newsroom/brand-assets/logos/pluralsight-logo-vrt-color-2.png)  

Hi! 

Welcome to the GitHub repository of the GetyourLoanApp application.
This app is the demo app for the Pluralsight course [JavaScript Variables and Types](https://app.pluralsight.com/library/courses/javascript-variables-types/).

You can download a copy of the code and follow along in the course.

The application consists out of a simple HTML file, with some CSS and, most importantlty, a JavaScript file. 
